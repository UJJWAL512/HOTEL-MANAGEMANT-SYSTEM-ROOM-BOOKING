<?php
$con = mysqli_connect("localhost","root","","hotel") or die(mysql_error());

?>